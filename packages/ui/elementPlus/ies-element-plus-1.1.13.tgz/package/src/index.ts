import type { PluginManager } from '@ies/manager';
import type { SetupConfig } from '@ies/types';

import { watchEffect } from 'vue';

// 注册element-plus ui
import { pluginManager as pManager } from '@ies/manager';
import {
  ElCollapse,
  ElCollapseItem,
  ElFormItem,
  ElMessage,
} from 'element-plus';

import Button from './button';
import Card from './card';
import Cascader from './cascader';
import Checkbox from './checkbox';
import Col from './col';
import Collapse from './collapse';
import CollapseItem from './collapse-item';
import ColorPicker from './color-picker';
import DatePicker from './date-picker';
import Form from './form';
import FormItem from './formItem';
import Input from './input';
import InputNumber from './input-number';
import Modal from './modal';
import Radio from './radio';
import Row from './row';
import Select from './select';
import Slider from './slider';
import Switch from './switch';
import TabsPane from './tab-pane';
import Tabs from './tabs';
import Textarea from './textarea';
import UploadFile from './upload-file';
import UploadImage from './upload-image';

// 引入样式
import './index.less';

export function setupElementPlus(
  pluginManager: PluginManager = pManager,
  config: SetupConfig = {},
): void {
  pluginManager.component.add('FormItem', ElFormItem);
  pluginManager.component.add('Collapse', ElCollapse);
  pluginManager.component.add('CollapseItem', ElCollapseItem);

  const componentArray = [
    Form,
    FormItem,
    Input,
    Textarea,
    InputNumber,
    Radio,
    Checkbox,
    DatePicker,
    Select,
    Switch,
    ColorPicker,
    Cascader,
    Slider,
    UploadFile,
    UploadImage,
    Button,
    Card,
    Row,
    Col,
    Collapse,
    CollapseItem,
    Modal,
    Tabs,
    TabsPane,
  ];

  const { uploadFile, uploadImage } = config;
  // 若配置了图片上传地址，则覆盖上传组件的默认接口地址
  if (uploadImage) UploadImage.defaultSchema.props.action = uploadImage;
  // 若配置了文件上传地址，则覆盖上传组件的默认接口地址
  if (uploadFile) UploadFile.defaultSchema.props.action = uploadFile;

  // 更新默认上传地址相关配置
  watchEffect(() => {
    // 当全局配置图片上传地址时，过滤该属性配置，默认使用全局配置
    if (pluginManager.global.uploadImage) {
      UploadImage.config.attribute = UploadImage.config.attribute?.filter(
        (item) => item.field !== 'props.action',
      );
    }
    // 当全局配置文件上传地址时，过滤该属性配置，默认使用全局配置
    if (pluginManager.global.uploadFile) {
      UploadFile.config.attribute = UploadFile.config.attribute?.filter(
        (item) => item.field !== 'props.action',
      );
    }
  });

  componentArray.forEach((item) => {
    pluginManager.component.register(item);
    pluginManager.component.addBaseComponentType(item.defaultSchema.type);
  });

  // 注册全局提示函数
  pluginManager.global.$message = {
    error: ElMessage.error,
    info: ElMessage.info,
    success: ElMessage.success,
    warning: ElMessage.warning,
  };

  // ui初始化完成。
  pluginManager.designer.setInitialized(true);
}

/**
 * 设置element GlobalConfig
 */
export function provideGlobalConfig(args: any) {
  import('element-plus').then(({ provideGlobalConfig }) => {
    provideGlobalConfig(args);
  });
}
