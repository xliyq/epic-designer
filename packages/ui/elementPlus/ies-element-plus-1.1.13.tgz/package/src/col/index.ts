import type { ComponentConfigModel } from '@ies/types';

export default {
  component: () => import('./col'),
  config: {
    attribute: [
      {
        field: 'props.span',
        label: '占位格数',
        type: 'number',
      },
    ],
  },
  defaultSchema: {
    label: '栅格布局-列',
    props: {
      span: 6,
    },
    type: 'col',
    children: [],
  },
  editConstraints: {
    locked: true,
  },
} as ComponentConfigModel;
